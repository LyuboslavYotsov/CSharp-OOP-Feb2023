﻿using System;
using System.Collections.Generic;

namespace CustomStack;

public class StartUp
{
    static void Main(string[] args)
    {
        StackOfStrings myStack = new StackOfStrings();

        Console.WriteLine(myStack.IsEmpty());
        List<string> myList = new List<string>()
        {
            "asd",
            "dfd",
            "f",
            "u",
            "c",
            "o",
            "B",
            "u",
            "B",
        };
        myStack.AddRange(myList);

        foreach (var item in myStack)
        {
            Console.WriteLine(item);
        }
    }
}